This is the website I've made with HTML, CSS and bootstrap.
Mohit Bhalla
IIT Roorkee